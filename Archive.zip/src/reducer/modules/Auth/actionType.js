
export const AUTH_PLAYER_ID = 'ChartGain.AUTH/PLAYER_ID'

export const AUTH_SIGN_UP = 'ChartGain.AUTH/SIGN_UP'
export const AUTH_SIGN_UP_SUCESS = 'ChartGain.AUTH/SIGN_UP_SUCCESS'