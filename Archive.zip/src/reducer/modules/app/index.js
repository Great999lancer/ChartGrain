export { app } from './reducer'
export { connectApp } from './connectApp'
export { appActionCreators } from './actions'
export { default as appSaga } from './saga'

import * as appTYPE from './actionType'
export default appTYPE