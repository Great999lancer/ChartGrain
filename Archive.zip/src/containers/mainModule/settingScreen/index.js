import page from './page'
import { connectApp } from '../../../reducer/modules'
export default connectApp()(page)