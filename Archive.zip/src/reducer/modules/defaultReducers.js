const app = {
  root: undefined
}

const Auth = {

}

export const defaultReducers = {
  app,
  Auth
}