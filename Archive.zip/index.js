
import App from './App';

const app = new App()