export const navigatorStyle = {
  navBarHidden: true,
  tabBarHidden: true,
  statusBarHidden: true,
  drawUnderTabBar: true,
  disabledBackGesture: true
}